import json
import os
import mysql.connector
from mysql.connector import errorcode
from datetime import datetime


def lambda_handler(event, context):
    # TODO implement

    # Define tables
    TABLES = {}
    TABLES['PCHomeProducts'] = (
        "CREATE TABLE `PCHomeProducts` ("
        "`PCHMainID` bigint not null auto_increment primary key,"
        "`ProductID` varchar(25) not null unique,"
        "`ProductName` varchar(255) not null,"
        "`ProductNick` varchar(255) not null,"
        "`ProductDescription` varchar(3000) default 'NONE',"
        "`CurrentPrice` int not null,"
        "`ProductAvailability` varchar(20) not null,"
        "`ProductURL` varchar(100) not null,"
        "`DateTime` DATETIME default CURRENT_TIMESTAMP,"
        "`EnglishWords` varchar(40) default null,"
        "`ChineseWords` varchar(5000) default null, "
        "`NumberWords` varchar(40) default null, "
        "FULLTEXT `fulltext_index` (`ProductName`, `ProductNick`),"
        "FULLTEXT `keywords_index` (`EnglishWords`), "
        "FULLTEXT `keywords_index` (`ChineseWords`), "
        "FULLTEXT `keywords_index` (`NumberWords`), "
        "INDEX (`ProductID`) "
        ") ENGINE=InnoDB CHARACTER SET = utf8mb4")

    TABLES['PCHomePic'] = (
        "CREATE TABLE `PCHomePic` ("
        "`PCHPicID` bigint not null auto_increment primary key,"
        " `ProductID` varchar(25) not null,"
        " `PicURL` varchar(100) not null,"
        " `DateTime` DATETIME default CURRENT_TIMESTAMP,"
        " FOREIGN KEY (`ProductID`) REFERENCES `PCHomeProducts` (`ProductID`) ON DELETE CASCADE "
        ") ENGINE=InnoDB CHARACTER SET = utf8mb4")

    TABLES['PCHomeProdCategory'] = (
        "CREATE TABLE `PCHomeProdCategory` ("
        "`PCHCateID` bigint not null auto_increment primary key,"
        " `ProductID` varchar(25) not null,"
        " `CategoryCode` varchar(10) not null,"
        " `CategoryName` varchar(20) not null,"
        " `CategoryLevel` int(10) not null,"
        " `DateTime` DATETIME default CURRENT_TIMESTAMP,"
        " FOREIGN KEY (`ProductID`) REFERENCES `PCHomeProducts` (`ProductID`) ON DELETE CASCADE "
        ") ENGINE=InnoDB CHARACTER SET = utf8mb4")

    # Connect to database
    DB_NAME = os.environ['DB_DB']
    mydb = mysql.connector.connect(
        host=os.environ['DB_HOST'],
        user=os.environ['DB_USER'],
        password=os.environ['DB_PASSWORD'],
    )
    cursor = mydb.cursor()

    # Create database
    try:
        cursor.execute("USE {}".format(DB_NAME))
    except mysql.connector.Error as err:
        print("Database {} does not exists.".format(DB_NAME))
        if err.errno == errorcode.ER_BAD_DB_ERROR:
            create_database(cursor)
            print("Database {} created successfully.".format(DB_NAME))
            mydb.database = DB_NAME
        else:
            print(err)
            exit(1)

    # Create tables
    for table_name in TABLES:
        table_description = TABLES[table_name]
        # print(table_description)
        try:
            print("Creating table {}: ".format(table_name), end='')
            cursor.execute(table_description)
        except mysql.connector.Error as err:
            if err.errno == errorcode.ER_TABLE_EXISTS_ERROR:
                print("already exists.")
            else:
                print(err.msg)
        else:
            print("OK")

    cursor.close()

    # Define data insertion statement
    add_products = ("INSERT INTO PCHomeProducts"
                    "(ProductID, ProductName, ProductNick, ProductDescription, CurrentPrice, ProductAvailability, ProductURL) "
                    "VALUES (%(Id)s, %(Name)s, %(Nick)s, %(Slogan)s, %(P)s, %(ButtonType)s, %(url)s)")

    add_pic = ("INSERT INTO PCHomePic"
            "(ProductID, PicURL) "
            "VALUES (%(Id)s, %(B)s)")

    add_category = ("INSERT INTO PCHomeProdCategory"
                    "(ProductID, CategoryCode, CategoryName, CategoryLevel) "
                    "VALUES (%(Id)s, %(CateCode)s, %(CateName)s, %(CateLevel)s)")

    update_products = ("UPDATE PCHomeProducts "
                    " SET ProductName = %(Name)s, ProductNick=%(Nick)s, ProductDescription=%(Slogan)s, CurrentPrice=%(P)s, ProductAvailability=%(ButtonType)s, ProductURL=%(url)s "
                    "WHERE ProductID=%(Id)s")

    update_pic = ("UPDATE PCHomePic "
                "SET PicURL=%(B)s "
                "WHERE ProductID=%(Id)s")

    update_category = ("UPDATE PCHomeProdCategory "
                    "SET CategoryCode=%(CateCode)s, CategoryName=%(CateName)s, CategoryLevel=%(CateLevel)s "
                    "WHERE ProductID=%(Id)s")


    # Read SQS msg
    prods = event['Records']['body'][0:len(event['Records']['body'])-3]
    prodDesc = event['Records']['body'][-1]['description']
    prodSale = event['Records']['body'][-2]['salestatus']

    # Insert PChome Data to DB
    addListProd = []
    updateListProd = []
    addListCate = []
    addListPic = []
    updateListPic = []
    

    # Organize data to fetch to the database
    for i in range(len(prods)-3):
        prod = {"Id": prods[i]['Id'], "Name": prods[i]['Name'], "Nick": prods[i]['Nick'], "P": prods[i]["Price"]["P"],
                "url": "https://24h.pchome.com.tw/prod/"+prods[i]["Id"][0:-4]}
        if prodSale:
            prod.update({"ButtonType": prodSale[i]["ButtonType"]})
        else:
            prod.update({"ButtonType": 'None'})
        if prodDesc:
            prod.update({"Slogan": prodDesc[prod['Id'][0:-4]]["Slogan"]})
        else:
            prod.update({"Slogan": 'None'})

        cursor.execute(
            "select * from PCHomeProducts where ProductID=%s", (prod['Id'],))
        result = cursor.fetchone()
        if result:
            # Update existing data
            print(f'Update existing data, prodID={prod["Id"]}')
            updateListProd.append(prod)
            if prods[i]["Pic"]["B"]:
                updateListPic.append({
                    "Id": prod["Id"], "B": "https://cs-f.ecimg.tw"+prods[i]["Pic"]["B"]})
            else:
                updateListPic.append({
                    "Id": prod["Id"], "B": "None"})

            cursor.execute("select ProductID, date_format(DateTime, '%Y%m%d')  from PCHomeProdCategory where ProductID=%s",
                           (prod["Id"],))
            result = cursor.fetchall()
            if result:
                if result[0][1] <= str(int(datetime.strftime(datetime.now(), '%Y%m%d'))-1):
                    # Delete the data updated yesterday
                    cursor.execute(
                        "DELETE FROM PCHomeProdCategory WHERE ProductID = %s", (prod["Id"],))
                    mydb.commit()
        else:
            # Add new data
            print(f'Add new data, prodID={prods[i]["Id"]}')
            addListProd.append(prod)
            if prods[i]["Pic"]["B"]:
                addListPic.append({
                    "Id": prod["Id"], "B": "https://cs-f.ecimg.tw"+prods[i]["Pic"]["B"]})
            else:
                addListPic.append({
                    "Id": prod["Id"], "B": "None"})

        # handle category
        addListCate.append({
            "Id": prod["Id"], "CateCode": prods[-3]["Category"]['L0CategoryCode'], "CateName": prods[-3]["Category"]['L0CategoryName'], "CateLevel": 0})
        addListCate.append({
            "Id": prod["Id"], "CateCode": prods[-3]["Category"]['L1CategoryCode'], "CateName": prods[-3]["Category"]['L1CategoryName'], "CateLevel": 1})
        addListCate.append({
            "Id": prod["Id"], "CateCode": prods[-3]["Category"]['L2CategoryCode'], "CateName": prods[-3]["Category"]['L2CategoryName'], "CateLevel": 2})
    
    print("Uploading data to DB")
    cursor = mydb.cursor()
    cursor.executemany(update_products, updateListProd)
    mydb.commit()
    cursor.executemany(add_products, addListProd)
    mydb.commit()
    cursor.executemany(update_pic, updateListPic)
    mydb.commit()
    cursor.executemany(add_pic, addListPic)
    mydb.commit()
    cursor.executemany(add_category, addListCate)
    mydb.commit()

    cursor.close()
    mydb.close()

    return {
        'statusCode': 200,
        'body': json.dumps(f'Category code: {prods[-3]["Category"]["L2CategoryCode"]}, Category name:{prods[-3]["Category"]["L2CategoryName"]} updates to DB successfully!')
    }

def readFile(relative_path):
    """
    relative_path ="pchome-prod/DAAO00_prod.txt"
    return data
    """
    abs_path=os.getcwd()
    full_path=os.path.join(abs_path, relative_path)
    
    with open(full_path, 'r') as f:
        json_data=f.read()
        data = json.loads(json_data)
    
    return data

def create_database(cursor):
    try:
        cursor.execute(
            "CREATE DATABASE {} DEFAULT CHARACTER SET 'utf8'".format(DB_NAME))
    except mysql.connector.Error as err:
        print("Failed creating database: {}".format(err))
        exit(1)

